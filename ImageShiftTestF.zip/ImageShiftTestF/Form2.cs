﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Diagnostics;
using Debug = System.Diagnostics.Debug;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Reflection;
using Accord.IO;

namespace ChekMountPosition
{

	// per le WebAPI vedi https://drive.google.com/file/d/15AFMQSMlMdpjL2USPsvYd-J9xWecrEf9/view
	public partial class Form2 : Form
	{
		public Form2()
		{
			InitializeComponent();
		}

		PatternVerifier patternVerifier = new PatternVerifier();
		private Config config { get { return patternVerifier.Config; } set { patternVerifier.Config = value; } }
		private string configFilename;// = @"c:\temp\ChekMountPosition.json";


		private void Form2_Load(object sender, EventArgs e)
		{
			Form2_Resize(sender, e);
			var appdata = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
			Directory.CreateDirectory(appdata);
			configFilename = Path.Combine(appdata, "ChekMountPosition.json");
			config = Config.Load(configFilename);
			pictureBox1.Image = config.ReferenceImage;
		}


		private void buttonLoadImage_Click(object sender, EventArgs e)
		{
			var loader = new ImageLoader();
			var image = loader.Load(config.SourceType, config.Source);
			patternVerifier.NewImage = image;
			pictureBox2.Image = patternVerifier.NewImage;
			patternVerifier.SearchMatch();
		}

		private void btSaveCfg_Click(object sender, EventArgs e)
		{
			config.Save(configFilename);

		}

		private void btLoadCfg_Click(object sender, EventArgs e)
		{
			config = Config.Load(configFilename);

			pictureBox1.Image = config.ReferenceImage;
		}

		private void btSetRefImage_Click(object sender, EventArgs e)
		{
			pictureBox1.Image = patternVerifier.NewImage;
			config.ReferenceImage = patternVerifier.NewImage;
		}

		SelectionMode SelectionState = SelectionMode.off;
		System.Drawing.Point SelectionFirstPoint;
		System.Drawing.Point SelectionLastPoint;

		private void btAddRegion_Click(object sender, EventArgs e)
		{
			//SelectionState = SelectionMode.WaitingStart;
			//Cursor.Current = Cursors.Cross;
		}

		private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
		{
			if (SelectionState == SelectionMode.off)
			{
				SelectionFirstPoint = e.Location;
				SelectionState = SelectionMode.WaitingEnd;
				pictureBox1.Cursor = Cursors.Cross;
			}
		}

		private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
		{
			SelectionLastPoint = e.Location;
			pictureBox1.Invalidate();
		}

		private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
		{
			if (SelectionState == SelectionMode.WaitingEnd)
			{
				var startPoint = SelectionFirstPoint;
				var endPoint = e.Location;
				//
				GetStretch(pictureBox1, out var stretchX, out var stretchY, out var shiftX, out var shiftY);

				Zone item = new Zone
				{
					X = (int)((startPoint.X - shiftX) / stretchX),
					Y = (int)((startPoint.Y - shiftY) / stretchY),
					Width = (int)((endPoint.X - startPoint.X) / stretchX),
					Height = (int)((endPoint.Y - startPoint.Y) / stretchY)
				};
				if (item.Width >= 10 && item.Height >= 10)
					config.Templates.Add(item);

				//				
				Cursor.Current = Cursors.Default;
				SelectionState = SelectionMode.off;
			}
		}

		private void pictureBox1_Paint(object sender, PaintEventArgs e)
		{
			GetStretch((PictureBox)sender, out var stretchX, out var stretchY, out var shiftX, out var shiftY);
			var g = e.Graphics;
			foreach (var tp in config.Templates)
			{
				g.DrawRectangle(new Pen(Color.Blue, 1), (int)(tp.X * stretchX) + shiftX, (int)(tp.Y * stretchY) + shiftY, (int)(tp.Width * stretchX), (int)(tp.Height * stretchY));

			}
			if (SelectionState == SelectionMode.WaitingEnd)
			{

				g.DrawRectangle(new Pen(Color.Coral, 1), SelectionFirstPoint.X, SelectionFirstPoint.Y, SelectionLastPoint.X - SelectionFirstPoint.X, SelectionLastPoint.Y - SelectionFirstPoint.Y);
			}
		}

		private void GetStretch(PictureBox pb, out double stretchX, out double stretchY, out int shiftX, out int shiftY)
		{

			if (pb.Image == null || pb.SizeMode == PictureBoxSizeMode.Normal)
			{
				stretchX = 1;
				stretchY = 1;
				shiftX = 0;
				shiftY = 0;
			}
			else
			{
				PropertyInfo irProperty = typeof(PictureBox).GetProperty("ImageRectangle", BindingFlags.GetProperty | BindingFlags.NonPublic | BindingFlags.Instance);
				Rectangle rr = (Rectangle)irProperty.GetValue(pb, null);

				stretchX = (double)rr.Width / pb.Image.Width;
				stretchY = (double)rr.Height / pb.Image.Height;
				shiftX = rr.X;
				shiftY = rr.Y;
			}
		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{
			MouseEventArgs me = (MouseEventArgs)e;
			GetStretch(pictureBox1, out var stretchX, out var stretchY, out var shiftX, out var shiftY);
			var X = (me.X - shiftX) / stretchX;
			var Y = (me.Y - shiftY) / stretchY;
			for (int i = config.Templates.Count - 1; i >= 0; i--)
			{
				Zone tp = config.Templates[i];
				if (tp.X <= X && X <= tp.X + tp.Width && tp.Y <= Y && Y <= tp.Y + tp.Height)
				{
					config.Templates.RemoveAt(i);
				}
			}

		}

		private void btClearRegions_Click(object sender, EventArgs e)
		{
			config.Templates.Clear();
			pictureBox1.Invalidate();
		}

		private void btCheckImage_Click(object sender, EventArgs e)
		{
			patternVerifier.ZoneMatchList.Clear();
			pictureBox2.Invalidate();
			Application.DoEvents();
			patternVerifier.SearchMatch();
			pictureBox2.Invalidate();
		}

		private void pictureBox2_Paint(object sender, PaintEventArgs e)
		{
			GetStretch((PictureBox)sender, out var stretchX, out var stretchY, out var shiftX, out var shiftY);
			var g = e.Graphics;
			foreach (var zoneMatch in patternVerifier.ZoneMatchList)
			{
				Color color;
				var sp = zoneMatch.Source;
				var tp = zoneMatch.Target;
				if (sp.X == tp.X && sp.Y == tp.Y && sp.Width == tp.Width && sp.Height == tp.Height)
				{
					color = Color.Green;
					g.DrawRectangle(new Pen(color, 1), (int)(tp.X * stretchX) + shiftX, (int)(tp.Y * stretchY) + shiftY, (int)(tp.Width * stretchX), (int)(tp.Height * stretchY));
				}
				else
				{
					color = Color.Blue;
					g.DrawRectangle(new Pen(color, 1), (int)(sp.X * stretchX) + shiftX, (int)(sp.Y * stretchY) + shiftY, (int)(sp.Width * stretchX), (int)(sp.Height * stretchY));
					color = Color.Red;
					g.DrawRectangle(new Pen(color, 1), (int)(tp.X * stretchX) + shiftX, (int)(tp.Y * stretchY) + shiftY, (int)(tp.Width * stretchX), (int)(tp.Height * stretchY));
				}


			}
		}

		private void Form2_Resize(object sender, EventArgs e)
		{
			var dX = pictureBox1.Left;
			var top = pictureBox1.Top;
			var width = (ClientSize.Width - dX * 3) / 2;
			var height = ClientSize.Height - top - dX;

			pictureBox1.Top = pictureBox2.Top = top;

			pictureBox1.Width = pictureBox2.Width = width;
			pictureBox1.Height = pictureBox2.Height = height;
			pictureBox2.Left = width + dX * 2;
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox1.Checked)
			{
				pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
				pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
			}
			else
			{
				pictureBox1.SizeMode = PictureBoxSizeMode.Normal;
				pictureBox2.SizeMode = PictureBoxSizeMode.Normal;
			}
			pictureBox1.Invalidate();
			pictureBox2.Invalidate();

		}

		private void btSettings_Click(object sender, EventArgs e)
		{
			using (var f = new SettingsForm())
			{

				f.Config = config.Clone();
				if (f.ShowDialog(this) == DialogResult.OK)
				{
					config = f.Config;
				}
			}
		}

		private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
		{
			pictureBox2.Image = patternVerifier.Config.ReferenceImage;
		}

		private void pictureBox2_MouseUp(object sender, MouseEventArgs e)
		{
			pictureBox2.Image = patternVerifier.NewImage;
		}
	}
	public enum SelectionMode { off, WaitingEnd }
}
