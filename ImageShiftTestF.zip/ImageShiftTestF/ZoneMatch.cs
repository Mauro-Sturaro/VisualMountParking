﻿namespace ChekMountPosition
{
	public class ZoneMatch
	{
		public Zone Source { get; set; }
		public Zone Target { get; set; }

	}
}
