﻿using ChekMountPosition.Properties;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace ChekMountPosition
{
	internal class ImageLoader
	{
		public Bitmap Load(ImageSourceType sourceType, string source)
		{
			try
			{
				if (sourceType == ImageSourceType.URL)
					return LoadFromUrl(source);
				else
					return LoadFromFile(source);

			}
			catch (Exception e)
			{
				return Resources.error;
			}
		}

		private Bitmap LoadFromFile(string source)
		{
			var image = Image.FromFile(source);
			if (image is Bitmap)
				return (Bitmap)image;
			return new Bitmap(image);
		}

		private Bitmap LoadFromUrl(string imageUrl)
		{
			WebClient client = new WebClient();
			Stream stream = client.OpenRead(imageUrl);
			var image = Image.FromStream(stream);
 
			stream.Flush();
			stream.Close();
			client.Dispose();

			if (image is Bitmap)
				return (Bitmap)image;
			return new Bitmap(image);
		}
	}
}
