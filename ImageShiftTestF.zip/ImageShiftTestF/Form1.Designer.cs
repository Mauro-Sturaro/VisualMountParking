﻿namespace ChekMountPosition
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.picCamera = new System.Windows.Forms.PictureBox();
			this.button1 = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.btImage1 = new System.Windows.Forms.Button();
			this.picImage1 = new System.Windows.Forms.PictureBox();
			this.btSave = new System.Windows.Forms.Button();
			this.btLive = new System.Windows.Forms.Button();
			this.txtOffsetX = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.txtOffsetY = new System.Windows.Forms.TextBox();
			((System.ComponentModel.ISupportInitialize)(this.picCamera)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.picImage1)).BeginInit();
			this.SuspendLayout();
			// 
			// picCamera
			// 
			this.picCamera.Location = new System.Drawing.Point(334, 83);
			this.picCamera.Name = "picCamera";
			this.picCamera.Size = new System.Drawing.Size(640, 480);
			this.picCamera.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.picCamera.TabIndex = 0;
			this.picCamera.TabStop = false;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 9);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "Select Device";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(89, 11);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(492, 20);
			this.textBox1.TabIndex = 2;
			// 
			// btImage1
			// 
			this.btImage1.Location = new System.Drawing.Point(8, 38);
			this.btImage1.Name = "btImage1";
			this.btImage1.Size = new System.Drawing.Size(75, 23);
			this.btImage1.TabIndex = 3;
			this.btImage1.Text = "Image 1";
			this.btImage1.UseVisualStyleBackColor = true;
			this.btImage1.Click += new System.EventHandler(this.btImage1_Click);
			// 
			// picImage1
			// 
			this.picImage1.Location = new System.Drawing.Point(8, 83);
			this.picImage1.Name = "picImage1";
			this.picImage1.Size = new System.Drawing.Size(320, 200);
			this.picImage1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.picImage1.TabIndex = 5;
			this.picImage1.TabStop = false;
			// 
			// btSave
			// 
			this.btSave.Location = new System.Drawing.Point(170, 37);
			this.btSave.Name = "btSave";
			this.btSave.Size = new System.Drawing.Size(75, 23);
			this.btSave.TabIndex = 11;
			this.btSave.Text = "Save";
			this.btSave.UseVisualStyleBackColor = true;
			this.btSave.Click += new System.EventHandler(this.btSave_Click);
			// 
			// btLive
			// 
			this.btLive.Location = new System.Drawing.Point(89, 38);
			this.btLive.Name = "btLive";
			this.btLive.Size = new System.Drawing.Size(75, 23);
			this.btLive.TabIndex = 14;
			this.btLive.Text = "LIVE";
			this.btLive.UseVisualStyleBackColor = true;
			this.btLive.Click += new System.EventHandler(this.btLive_Click);
			// 
			// txtOffsetX
			// 
			this.txtOffsetX.Location = new System.Drawing.Point(319, 41);
			this.txtOffsetX.Name = "txtOffsetX";
			this.txtOffsetX.Size = new System.Drawing.Size(79, 20);
			this.txtOffsetX.TabIndex = 15;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(270, 44);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(43, 13);
			this.label1.TabIndex = 16;
			this.label1.Text = "offset X";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(417, 44);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(43, 13);
			this.label2.TabIndex = 18;
			this.label2.Text = "offset Y";
			// 
			// txtOffsetY
			// 
			this.txtOffsetY.Location = new System.Drawing.Point(466, 41);
			this.txtOffsetY.Name = "txtOffsetY";
			this.txtOffsetY.Size = new System.Drawing.Size(79, 20);
			this.txtOffsetY.TabIndex = 17;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(980, 571);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtOffsetY);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtOffsetX);
			this.Controls.Add(this.btLive);
			this.Controls.Add(this.btSave);
			this.Controls.Add(this.picImage1);
			this.Controls.Add(this.btImage1);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.picCamera);
			this.Name = "Form1";
			this.Text = "Form1";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.picCamera)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.picImage1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.PictureBox picCamera;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button btImage1;
		private System.Windows.Forms.PictureBox picImage1;
		private System.Windows.Forms.Button btSave;
		private System.Windows.Forms.Button btLive;
		private System.Windows.Forms.TextBox txtOffsetX;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtOffsetY;
	}
}

