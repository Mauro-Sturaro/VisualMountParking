﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Accord.Video;
using Accord.Video.DirectShow;
using Accord;
using Accord.Imaging;
using Accord.Imaging.Filters;
using Accord.Math;
using System.IO;
using Accord.MachineLearning;


// Ideas and code from https://www.codeproject.com/Articles/95453/Automatic-Image-Stitching-with-Accord-NET

namespace ChekMountPosition
{
	public partial class Form1 : Form
	{
		VideoCaptureDevice videoSource;

		string imgFile1 = @"c:\temp\img1.img";
		string deviceFile = @"c:\temp\device.txt";

		bool liveShow = true;

		// Images we are going to stitch together
		private Bitmap referenceImage;
		private Bitmap lastImage;



		public Form1()
		{
			InitializeComponent();
			picCamera.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			StopVideoSource();

			var selectionForm = new VideoCaptureDeviceForm();
			var result = selectionForm.ShowDialog();
			StopVideoSource();

			if (result != DialogResult.OK)
				return;

			textBox1.Text = selectionForm.VideoDeviceMoniker;
			videoSource = selectionForm.VideoDevice;
			videoSource.NewFrame += VideoSource_NewFrame;
			videoSource.Start();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			if (File.Exists(imgFile1))
			{
				referenceImage = (Bitmap)System.Drawing.Image.FromFile(imgFile1);
				picImage1.Image = referenceImage;
			}
			if (File.Exists(deviceFile))
			{
				var devMoniker = File.ReadAllText(deviceFile);
				textBox1.Text = devMoniker;
				videoSource = new VideoCaptureDevice(devMoniker);
				videoSource.NewFrame += VideoSource_NewFrame;
				videoSource.Start();
			}

		}

		private void VideoSource_NewFrame(object sender, NewFrameEventArgs eventArgs)
		{
			lastImage = (Bitmap)eventArgs.Frame.Clone();

			if (picImage1.Image == null)
			{
				referenceImage = lastImage;
				picImage1.Image = lastImage;
			}

			if (liveShow)
				UpdateLive((Bitmap)lastImage.Clone());
			else
				picCamera.Image = lastImage;
		}

		void StopVideoSource()
		{
			liveShow = false;
			Application.DoEvents();
			if (videoSource != null)
			{
				videoSource.NewFrame -= VideoSource_NewFrame;
				videoSource.Stop();
				videoSource = null;
			}
		}
		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			StopVideoSource();
		}

		private void btImage1_Click(object sender, EventArgs e)
		{
			referenceImage = lastImage;
			picImage1.Image = referenceImage;
		}


		private void btSave_Click(object sender, EventArgs e)
		{
			referenceImage.Save(imgFile1);
			//	img2.Save(imgFile2);
			File.WriteAllText(deviceFile, textBox1.Text);

		}


		private void btLive_Click(object sender, EventArgs e)
		{
			liveShow = !liveShow;
			return;
		}

		private void UpdateLive(Bitmap newImage)
		{
			// riduco le immagini a dimensioni ragionevoli
			var sizeTransformation = new ResizeBilinear(640, 480);
			var img1 = sizeTransformation.Apply(referenceImage);
			var img2 = sizeTransformation.Apply(newImage);

			// Step 1: Detect feature points using Harris Corners Detector
			HarrisCornersDetector harris = new HarrisCornersDetector(0.04f, 1000f);
			var harrisPoints1 = harris.ProcessImage(img1).ToArray();
			var harrisPoints2 = harris.ProcessImage(img2).ToArray();

			// Step 2: Match feature points using a correlation measure
			CorrelationMatching matcher = new CorrelationMatching(9, img1, img2);
			IntPoint[][] matches = matcher.Match(harrisPoints1, harrisPoints2);

			// Get the two sets of points
			var correlationPoints1 = matches[0];
			var correlationPoints2 = matches[1];

			// Step 3: Create the homography matrix using a robust estimator
			RansacHomographyEstimator ransac = new RansacHomographyEstimator(0.001, 0.99);
			var homography = ransac.Estimate(correlationPoints1, correlationPoints2);

			// Plot RANSAC results against correlation results
			//IntPoint[] inliers1 = correlationPoints1.Submatrix(ransac.Inliers);
			//IntPoint[] inliers2 = correlationPoints2.Submatrix(ransac.Inliers);
			IntPoint[] inliers1 = correlationPoints1.Get(ransac.Inliers);
			IntPoint[] inliers2 = correlationPoints2.Get(ransac.Inliers);

			//// Show the marked correlations shift
			//PairsMarker pairs = new PairsMarker(
			//	inliers1,
			//	inliers2, Color.Red);

			//img2 = pairs.Apply(img2);

			// show centre point shift
			var pts1 = new PointF[1];
			pts1[0] = new PointF(img2.Width / 2, img2.Height / 2);

			var pts2 = homography.TransformPoints(pts1);

			PairsMarker pairsC = new PairsMarker(
				PointF2Int(pts1),
				PointF2Int(pts2), Color.Gold);

			img2 = pairsC.Apply(img2);

			// update picture
			picCamera.Image = img2;

			// Update delta fileds
			var dx = homography.OffsetX.ToString("+#0.00;-#0.00; 0.00");
			var dy = homography.OffsetY.ToString("+#0.00;-#0.00; 0.00");

			this.Invoke(new Action(() =>
			{
				txtOffsetX.Text = dx;
				txtOffsetY.Text = dy;
			}));

		}

		private IntPoint[] PointF2Int(PointF[] pts)
		{
			var result = new IntPoint[pts.Length];

			for (int i = 0; i < pts.Length; i++)
			{
				var p = pts[i];
				result[i] = new IntPoint((int)p.X, (int)p.Y);
			}
			return result;
		}
	}
}
